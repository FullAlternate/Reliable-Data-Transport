var searchData=
[
  ['diagnostics_2eh',['diagnostics.h',['../diagnostics_8h.html',1,'']]]
];
