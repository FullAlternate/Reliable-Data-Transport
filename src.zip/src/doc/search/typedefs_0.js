var searchData=
[
  ['application_5fdata_5fnode_5ft',['application_data_node_t',['../application__layer__impl_8h.html#aa5adac438a924726fca5b1ce437ff9b6',1,'application_layer_impl.h']]],
  ['application_5flayer_5ft',['application_layer_t',['../application__layer_8h.html#affd92a580b69dc2f2120d44db0d8e4e7',1,'application_layer.h']]]
];
