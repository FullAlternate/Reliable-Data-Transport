var indexSectionsWithContent =
{
  0: "acdilmnorstv",
  1: "anot",
  2: "adnort",
  3: "adnort",
  4: "acdilnorstv",
  5: "adnot",
  6: "d",
  7: "dl",
  8: "admnort",
  9: "r"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "enumvalues",
  8: "defines",
  9: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Enumerations",
  7: "Enumerator",
  8: "Macros",
  9: "Pages"
};

