var searchData=
[
  ['next',['next',['../structapplication__data__node.html#ad192e4106c658981b0eb2fe04e47f5cc',1,'application_data_node::next()'],['../structtimer__node.html#a96dcedb12fe998b12f44d26952a161df',1,'timer_node::next()']]],
  ['nw_5fdelay',['nw_delay',['../structnetwork__layer.html#a07683aa25272de8d2ef7adbebb592f8a',1,'network_layer']]],
  ['nw_5flayer',['nw_layer',['../structosi__stack.html#a300a64e31ca969bb946fd5998ca62de0',1,'osi_stack']]],
  ['nw_5fstddev',['nw_stddev',['../structnetwork__layer.html#aadbb54e9368bfe7c14a8d7b6c0e29ef7',1,'network_layer']]]
];
